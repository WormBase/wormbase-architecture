/* $Id: io.h,v 1.1 1998/04/17 20:43:50 mieg Exp $
 * skeletonized -- had been a longer version for perlio LS */

#include <stdio.h>
