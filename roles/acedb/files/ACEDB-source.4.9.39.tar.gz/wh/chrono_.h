

#ifndef CHRONO_PRIVATE_DEF
#define CHRONO_PRIVATE_DEF

typedef struct chonoStruct 
{ char *prok ; int call ; double tSys ; double tUser ; } Chrono ;


#endif  /* CHRONO_PRIVATE_DEF */


